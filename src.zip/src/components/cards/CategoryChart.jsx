



// import React from "react";
// import styled from "styled-components";
// import { PieChart } from "@mui/icons-material";

// const Card = styled.div`
//   flex: 1;
//   min-width: 280px;
//   padding: 24px;
//   border: 1px solid ${({ theme }) => theme.text_primary + 20};
//   border-radius: 14px;
//   box-shadow: 1px 6px 20px 0px ${({ theme }) => theme.primary + 15};
//   display: flex;
//   flex-direction: column;
//   gap: 6px;
//   @media (max-width: 600px) {
//     padding: 16px;
//   }
// `;
// const Title = styled.div`
//   font-weight: 600;
//   font-size: 16px;
//   color: ${({ theme }) => theme.primary};
//   @media (max-width: 600px) {
//     font-size: 14px;
//   }
// `;

// const CategoryChart = ({ data }) => {
//   return (
//     <Card>
//       <Title>Weekly Calories Burned</Title>
//       {data?.pieChartData && (
//         <PieChart
//           series={[
//             {
//               data: data.PieChartData,
//               innerRadius: 30,
//               outerRadius: 120,
//               paddingAngle: 5,
//               cornerRadius: 5,
//             },
//           ]}
//           width={400}
//           height={300}
//         />
//       )}
//     </Card>
//   );
// };

// export default CategoryChart;





// import React from "react";
// import styled from "styled-components";
// import { PieChart } from "@mui/icons-material";

// const Card = styled.div`
//   flex: 1;
//   min-width: 280px;
//   padding: 24px;
//   border: 1px solid ${({ theme }) => theme.text_primary + 20};
//   border-radius: 14px;
//   box-shadow: 1px 6px 20px 0px ${({ theme }) => theme.primary + 15};
//   display: flex;
//   flex-direction: column;
//   gap: 6px;
//   @media (max-width: 600px) {
//     padding: 16px;
//   }
// `;

// const Title = styled.div`
//   font-weight: 600;
//   font-size: 16px;
//   color: ${({ theme }) => theme.primary};
//   @media (max-width: 600px) {
//     font-size: 14px;
//   }
// `;

// const CategoryChart = ({ data }) => {
//   // Log the incoming data to check if it is being received
//   console.log("Received Data in CategoryChart:", data);

//   // Check if PieChartData exists and is an array
//   const chartData = data?.PieChartData ?? [];
//   console.log("PieChartData:", chartData);

//   return (
//     <Card>
//       <Title>Weekly Calories Burned</Title>
//       {chartData.length > 0 ? (
//         <PieChart
//           series={[
//             {
//               data: chartData, // Make sure data is correctly structured
//               innerRadius: 30,
//               outerRadius: 120,
//               paddingAngle: 5,
//               cornerRadius: 5,
//             },
//           ]}
//           width={400} // Ensure a width is provided
//           height={300}
//         />
//       ) : (
//         <p>No data available</p> // Show message if no data is passed
//       )}
//     </Card>
//   );
// };

// export default CategoryChart;








// import React from "react";
// import styled from "styled-components";
// //import { PieChart } from "@mui/icons-material";
// import { PieChart } from "@mui/x-charts";


// const Card = styled.div`
//   flex: 1;
//   min-width: 280px;
//   padding: 24px;
//   border: 1px solid ${({ theme }) => theme.text_primary + 20};
//   border-radius: 14px;
//   box-shadow: 1px 6px 20px 0px ${({ theme }) => theme.primary + 15};
//   display: flex;
//   flex-direction: column;
//   gap: 6px;
//   @media (max-width: 600px) {
//     padding: 16px;
//   }
// `;

// const Title = styled.div`
//   font-weight: 600;
//   font-size: 16px;
//   color: ${({ theme }) => theme.primary};
//   @media (max-width: 600px) {
//     font-size: 14px;
//   }
// `;

// const CategoryChart = ({ data }) => {
//   console.log("Received Data in CategoryChart:", data);

//   // Format data to match MUI PieChart requirements
//   const formattedData = data?.PieChartData?.map(item => ({
//     id: String(item.id), // Ensure id is a string
//     value: item.value,   // PieChart expects value
//     label: item.label
//   })) ?? [];

//   console.log("Formatted PieChartData:", formattedData);

//   return (
//     <Card>
//       <Title>Weekly Calories Burned</Title>
//       {formattedData.length > 0 ? (
//         <PieChart
//           series={[
//             {
//               data: formattedData, // Corrected data format
//               innerRadius: 30,
//               outerRadius: 120,
//               paddingAngle: 5,
//               cornerRadius: 5,
//             },
//           ]}
//           width={400}
//           height={300}
//         />
//       ) : (
//         <p>No data available</p>
//       )}
//     </Card>
//   );
// };

// export default CategoryChart;




// const CategoryChart = ({ data }) => {
//   return (
//     <Card>
//       <Title>Weekly Calories Burned</Title>
//       {data?.pieChartData && (
//         <PieChart
//           series={[
//             {
//               data: data?.pieChartData,
//               innerRadius: 30,
//               outerRadius: 120,
//               paddingAngle: 5,
//               cornerRadius: 5,
//             },
//           ]}
//           height={300}
//         />
//       )}
//     </Card>
//   );
// };

// export default CategoryChart;








// const CategoryChart = ({ data }) => {
//   console.log("Received Data in CategoryChart:", data);

//   if (!data || !data.pieChartData || data.pieChartData.length === 0) {
//     return (
//       <Card>
//         <Title>Weekly Calories Burned</Title>
//         <p>No data available</p>
//       </Card>
//     );
//   }

//   // ✅ Ensure correct PieChart data structure
//   const formattedData = data.pieChartData.map((item, index) => ({
//     id: String(index), // Ensure id is a string
//     value: item.value ?? 0, // Ensure value is a number
//     label: item.label || "Unknown", // Ensure label exists
//   }));

//   console.log("Formatted PieChartData:", formattedData);

//   return (
//     <Card>
//       <Title>Weekly Calories Burned</Title>
//       <PieChart
//         series={[
//           {
//             data: formattedData,
//             innerRadius: 30,
//             outerRadius: 120,
//             paddingAngle: 5,
//             cornerRadius: 5,
//           },
//         ]}
//         width={400}
//         height={300}
//       />
//     </Card>
//   );
// };

// export default CategoryChart;







import React from "react";
import styled from "styled-components";
import { PieChart } from "@mui/x-charts/PieChart";

const Card = styled.div`
  flex: 1;
  min-width: 280px;
  padding: 24px;
  border: 1px solid ${({ theme }) => theme.text_primary + 20};
  border-radius: 14px;
  box-shadow: 1px 6px 20px 0px ${({ theme }) => theme.primary + 15};
  display: flex;
  flex-direction: column;
  gap: 6px;
  @media (max-width: 600px) {
    padding: 16px;
  }
`;
const Title = styled.div`
  font-weight: 600;
  font-size: 16px;
  color: ${({ theme }) => theme.primary};
  @media (max-width: 600px) {
    font-size: 14px;
  }
`;

const CategoryChart = ({ data }) => {
  return (
    <Card>
      <Title>Weekly Calories Burned</Title>
      {data?.pieChartData && (
        <PieChart
          series={[
            {
              data: data?.pieChartData,
              innerRadius: 30,
              outerRadius: 120,
              paddingAngle: 5,
              cornerRadius: 5,
            },
          ]}
          height={300}
        />
      )}
    </Card>
  );
};

export default CategoryChart;