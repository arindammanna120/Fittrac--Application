// axios api
// import axios from "axios";

// const API=axios.create({
//     baseURL: "http://localhost:8080/api/user",
// });

// export const UserSignUp = async (data) => API.post("/user/signup", data);
// export const UserSignIn = async (data) => API.post("/user/signin", data);

// export const getDashboardDetails = async (token) =>
//   API.get("/user/dashboard", {
//     headers: { Authorization: `Bearer ${token}` },
//   });

// export const getWorkouts = async (token, date) =>
//   await API.get(`/user/workout${date}`, {
//     headers: { Authorization: `Bearer ${token}` },
//   });

// export const addWorkout = async (token, data) =>
//   await API.post(`/user/workout`, data, {
//     headers: { Authorization: `Bearer ${token}` },
//   });







import axios from "axios";

const API = axios.create({
    baseURL: "http://localhost:8080/api/user",    
    //baseURL: "http://localhost:8080/api/user",   
});

export const UserSignUp = async (data) => API.post("/signup", data);
export const UserSignIn = async (data) => API.post("/signin", data);

export const getDashboardDetails = async (token) =>
  API.get("/dashboard", {
    headers: { Authorization: `Bearer ${token}` },
  });

export const getWorkouts = async (token, date) =>
  API.get(`/workout?date=${date}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

export const addWorkout = async (token, data) =>
  API.post(`/workout`, data, {
    headers: { Authorization: `Bearer ${token}` },
  });








