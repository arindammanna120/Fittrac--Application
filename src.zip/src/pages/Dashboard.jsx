// import React, {  useState } from 'react';
// import styled from 'styled-components';
// import {counts} from "../utils/data";
// import WeeklyStatCard from '../components/cards/WeeklyStatCard';
// import CategoryChart from "../components/cards/CategoryChart";
// import AddWorkout from '../components/AddWorkout';
// import {Workoutcard}  from '../components/cards/Workoutcard';
// import CountCard from '../components/cards/CountCard';
// import { getDashboardDetails } from '../api';
// import { useEffect } from "react";
// import { useCallback } from "react";







// const Container=styled.div`
//   flex:1;
//   height:100%;
//   justify-content:center;
//   padding:22px 0px;
//   overflow-y:scroll;


// `;
// const Wrapper=styled.div`
//   flex:1;
//   max-width:1400px;
//   display:flex;
//   flex-direction:column;
//   gap:22px;
//   @media (max-width:600px){
//     gap:12px;
//   }

// `;
// const Title=styled.div`
//    font-size:22px;
//    color:${({theme})=>theme.text_primary};
//    font-weight:500;

//  `;

 
// const FlexWrap=styled.div`
//    display:flex;
//    flex-wrap:wrap;
//    justify-content:space-between;
//    gap:22px;
//    padding:0px 16px;
//    @media (max-width:600){
//     gap:12px;
//    }
// `;

// const Section=styled.div`
//   display: flex;
//   flex-direction: column;
//   padding: 0px 16px;
//   gap: 22px;
//   padding: 0px 16px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;
// const CardWrapper=styled.div`

//   display: flex;
//   flex-wrap: wrap;
//   justify-content: center;
//   gap: 20px;
//   margin-bottom: 100px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;


// export const Dashboard = () => {
  
// const [ setLoading] = useState(false);
// const [ setData] = useState(null);

//     const [workout,setWorkout]=useState("");

//     const data={
        
//             "TotalCaloriesBurnt": 15800,
//             "TotalWorkout": 7,
//             "AvgCaloriBurnPerWorkout": 2257,
//             "TotalWeeklyCaloriBurnt": {
//               "week": ["17th", "18th", "19th", "20th", "21st", "22nd"],
//               "CaloriBurned": [3200, 2500, 1800, 2700, 2800, 2600]
//             },
//             "PieChartData": [
//               {
//                 "id": 0,
//                 "value": 600,
//                 "label": "Legs"
//               },
//               {
//                 "id": 1,
//                 "value": 500,
//                 "label": "Arms"
//               },
//               {
//                 "id": 2,
//                 "value": 700,
//                 "label": "Cardio"
//               },
//               {
//                 "id": 3,
//                 "value": 450,
//                 "label": "Core"
//               },
//               {
//                 "id": 4, 
//                 "value": 400,
//                  "label": "Back"
//               },
//               {
//                 "id": 5, 
//                 "value": 300, 
//                 "label": "Shoulders"
//               }
//             ]
          
        
//        };


//        const dashboardData=async()=>{
//         setLoading(true)
//         const token=localStorage.getItem("your_secret_key")
//         await getDashboardDetails(token).then((res)=>{
//           setData(res.data);
//           console.log(res.data);
//           setLoading(false);
      
//         })
//        };


//        const getTodaysWorkout = async () => {
//         setLoading(true);
//         const token = localStorage.getItem("your_secret_key ");
//         await getWorkouts(token, "").then((res) => {
//           setTodaysWorkouts(res?.data?.todaysWorkouts);
//           console.log(res.data);
//           setLoading(false);
//         });
//       };
    
//       const addNewWorkout = async () => {
//         setButtonLoading(true);
//         const token = localStorage.getItem("fittrack-app-token");
//         await addWorkout(token, { workoutString: workout })
//           .then((res) => {
//             dashboardData();
//             getTodaysWorkout();
//             setButtonLoading(false);
//           })
//           .catch((err) => {
//             alert(err);
//           });
//       };

//       const getWorkouts = () => {
//         // Your function logic here
//     };
    
//       useEffect(() => {
//         dashboardData();
//         getTodaysWorkout();
//       }, [dashboardData, getTodaysWorkout]);


//       const [buttonLoading, setButtonLoading] = useState(false);
//       const [todaysWorkouts, setTodaysWorkouts] = useState([]);
//       const addWorkout = (workout) => {
//         // Function logic to add a workout
//     };
    


//    return (
//      <Container>
//         <Wrapper>
//             <Title>Dashboard</Title>
//             <FlexWrap>
//                 {counts.map((item)=>(
//                     <CountCard item={item} data={data}/>
//                 )
                
//                 )}
                
             
//             </FlexWrap>

//             <FlexWrap>
//                <WeeklyStatCard data={data}/>
//                <CategoryChart data={data}/>
//                <AddWorkout  workout={workout} 
//                setWorkout={setWorkout}
//                addNewWorkout={addNewWorkout}
//                buttonLoading={buttonLoading}
//                />
                
             
//             </FlexWrap>
//             <Section>
//                 <Title>Todays Workouts</Title>
//                 <CardWrapper>
//                     {/* <Workoutcard/> */}

//                     {todaysWorkouts.map((workout) => (
//                     <WorkoutCard workout={workout} />
//                     ))}
//                 </CardWrapper>
//             </Section>
//         </Wrapper>
//     </Container>
//   );
// };


// export default Dashboard;










// 



// import React, { useState, useEffect, useCallback } from 'react';
// import styled from 'styled-components';
// import { counts } from "../utils/data";
// import WeeklyStatCard from '../components/cards/WeeklyStatCard';
// import CategoryChart from "../components/cards/CategoryChart";
// import AddWorkout from '../components/AddWorkout';
// import Workoutcard from '../components/cards/Workoutcard';
// import CountCard from '../components/cards/CountCard';
// import { getDashboardDetails, getWorkouts, addWorkout } from '../api';

// const Container = styled.div`
//   flex: 1;
//   height: 100%;
//   justify-content: center;
//   padding: 22px 0px;
//   overflow-y: scroll;
// `;

// const Wrapper = styled.div`
//   flex: 1;
//   max-width: 1400px;
//   display: flex;
//   flex-direction: column;
//   gap: 22px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const Title = styled.div`
//   font-size: 22px;
//   color: ${({ theme }) => theme.text_primary};
//   font-weight: 500;
// `;

// const FlexWrap = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: space-between;
//   gap: 22px;
//   padding: 0px 16px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const Section = styled.div`
//   display: flex;
//   flex-direction: column;
//   padding: 0px 16px;
//   gap: 22px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const CardWrapper = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: center;
//   gap: 20px;
//   margin-bottom: 100px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// export const Dashboard = () => {
//   const [loading, setLoading] = useState(false);
//   const [data, setData] = useState(null);
//   const [workout, setWorkout] = useState("");
//   const [todaysWorkouts, setTodaysWorkouts] = useState([]);
//   const [buttonLoading, setButtonLoading] = useState(false);

//   const dashboardData = useCallback(async () => {
//     setLoading(true);
//     const token = localStorage.getItem("your_secret_key");
//     try {
//       const res = await getDashboardDetails(token);
//       setData(res.data);
//     } catch (error) {
//       console.error("Error fetching dashboard data:", error);
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   const getTodaysWorkout = useCallback(async () => {
//     setLoading(true);
//     const token = localStorage.getItem("your_secret_key");
//     try {
//       const res = await getWorkouts(token, "");
//       setTodaysWorkouts(res?.data?.todaysWorkouts || []);
//     } catch (error) {
//       console.error("Error fetching workouts:", error);
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   const addNewWorkout = async () => {
//     setButtonLoading(true);
//     const token = localStorage.getItem("your_secret_key");
//     try {
//       await addWorkout(token, { workoutString: workout });
//       dashboardData();
//       getTodaysWorkout();
//     } catch (err) {
//       alert(err);
//     } finally {
//       setButtonLoading(false);
//     }
//   };

//   useEffect(() => {
//     dashboardData();
//     getTodaysWorkout();
//   }, [dashboardData, getTodaysWorkout]);

//   return (
//     <Container>
//       <Wrapper>
//         <Title>Dashboard</Title>
//         <FlexWrap>
//           {counts.map((item) => (
//             <CountCard key={item.id} item={item} data={data} />
//           ))}
//         </FlexWrap>

//         <FlexWrap>
//           <WeeklyStatCard data={data} />
//           <CategoryChart data={data} />
//           <AddWorkout
//             workout={workout}
//             setWorkout={setWorkout}
//             addNewWorkout={addNewWorkout}
//             buttonLoading={buttonLoading}
//           />
//         </FlexWrap>

//         <Section>
//           <Title>Today's Workouts</Title>
//           <CardWrapper>
//             {todaysWorkouts.map((workout) => (
//               <Workoutcard key={workout.id} workout={workout} />
//             ))}
//           </CardWrapper>
//         </Section>
//       </Wrapper>
//     </Container>
//   );
// };

// export default Dashboard;









// import React, { useState, useEffect, useCallback } from "react";
// import styled from "styled-components";
// import { counts } from "../utils/data";
// import WeeklyStatCard from "../components/cards/WeeklyStatCard";
// import CategoryChart from "../components/cards/CategoryChart";
// import AddWorkout from "../components/AddWorkout";
// import Workoutcard from "../components/cards/Workoutcard"; // Fixed import
// import CountCard from "../components/cards/CountCard";
// import { getDashboardDetails, getWorkouts, addWorkout } from "../api"; // Ensure these API functions exist

// const Container = styled.div`
//   flex: 1;
//   height: 100%;
//   justify-content: center;
//   padding: 22px 0px;
//   overflow-y: scroll;
// `;

// const Wrapper = styled.div`
//   flex: 1;
//   max-width: 1400px;
//   display: flex;
//   flex-direction: column;
//   gap: 22px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const Title = styled.div`
//   font-size: 22px;
//   color: ${({ theme }) => theme.text_primary};
//   font-weight: 500;
// `;

// const FlexWrap = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: space-between;
//   gap: 22px;
//   padding: 0px 16px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const Section = styled.div`
//   display: flex;
//   flex-direction: column;
//   padding: 0px 16px;
//   gap: 22px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const CardWrapper = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: center;
//   gap: 20px;
//   margin-bottom: 100px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// // export const Dashboard = () => {
// //   const [loading, setLoading] = useState(false);
// //   const [data, setData] = useState(null);
// //   const [workout, setWorkout] = useState("");
// //   const [buttonLoading, setButtonLoading] = useState(false);
// //   const [todaysWorkouts, setTodaysWorkouts] = useState([]);

// //   // Fetch Dashboard Data
// //   const dashboardData = useCallback(async () => {
// //     setLoading(true);
// //     try {
// //       const token = localStorage.getItem("your_secret_key");
// //       const res = await getDashboardDetails(token);
// //       setData(res.data);
// //       console.log("Dashboard Data:", res.data);
// //     } catch (error) {
// //       console.error("Error fetching dashboard data:", error);
// //     }
// //     setLoading(false);
// //   }, []);

// //   // Fetch Today's Workouts
// //   const getTodaysWorkout = useCallback(async () => {
// //     setLoading(true);
// //     try {
// //       const token = localStorage.getItem("your_secret_key");
// //       const res = await getWorkouts(token, "");
// //       setTodaysWorkouts(res?.data?.todaysWorkouts || []);
// //       console.log("Today's Workouts:", res.data);
// //     } catch (error) {
// //       console.error("Error fetching workouts:", error);
// //     }
// //     setLoading(false);
// //   }, []);

// //   // Add New Workout
// //   const addNewWorkout = async () => {
// //     setButtonLoading(true);
// //     try {
// //       const token = localStorage.getItem("fittrack-app-token");
// //       await addWorkout(token, { workoutString: workout });
// //       await dashboardData();
// //       await getTodaysWorkout();
// //     } catch (err) {
// //       alert("Error adding workout: " + err.message);
// //     }
// //     setButtonLoading(false);
// //   };

// //   // Fetch Data on Component Mount
// //   useEffect(() => {
// //     dashboardData();
// //     getTodaysWorkout();
// //   }, [dashboardData, getTodaysWorkout]);

// //   return (
// //     <Container>
// //       <Wrapper>
// //         <Title>Dashboard</Title>
// //         <FlexWrap>
// //           {counts.map((item, index) => (
// //             <CountCard key={index} item={item} data={data} />
// //           ))}
// //         </FlexWrap>

// //         <FlexWrap>
// //           {/* Ensure WeeklyStatCard and CategoryChart get valid data */}
// //           {data?.TotalWeeklyCaloriBurnt ? (
// //             <WeeklyStatCard data={data} />
// //           ) : (
// //             <p>No Weekly Data</p>
// //           )}
// //           {data?.PieChartData ? (
// //             <CategoryChart data={data} />
// //           ) : (
// //             <p>No Category Data</p>
// //           )}

// //           <AddWorkout
// //             workout={workout}
// //             setWorkout={setWorkout}
// //             addNewWorkout={addNewWorkout}
// //             buttonLoading={buttonLoading}
// //           />
// //         </FlexWrap>

// //         <Section>
// //           <Title>Today's Workouts</Title>
// //           <CardWrapper>
// //             {todaysWorkouts.length > 0 ? (
// //               todaysWorkouts.map((workout, index) => (
// //                 <Workoutcard key={index} workout={workout} />
// //               ))
// //             ) : (
// //               <p>No Workouts Today</p>
// //             )}
// //           </CardWrapper>
// //         </Section>
// //       </Wrapper>
// //     </Container>
// //   );
// // };

// // export default Dashboard;





// export const Dashboard = () => {
//   const [loading, setLoading] = useState(false);
//   const [data, setData] = useState(null);
//   const [workout, setWorkout] = useState("");
//   const [buttonLoading, setButtonLoading] = useState(false);
//   const [todaysWorkouts, setTodaysWorkouts] = useState([]);

//   const dashboardData = useCallback(async () => {
//     setLoading(true);
//     try {
//       const token = localStorage.getItem("your_secret_key");
//       const res = await getDashboardDetails(token);
//       setData(res.data);
//       console.log("Dashboard Data:", res.data); // Debugging log
//     } catch (error) {
//       console.error("Error fetching dashboard data:", error);
//     }
//     setLoading(false);
//   }, []);

//   useEffect(() => {
//     dashboardData();
//   }, [dashboardData]);

//   return (
//     <Container>
//       <Wrapper>
//         <Title>Dashboard</Title>
//         <FlexWrap>
//           {counts.map((item, index) => (
//             <CountCard key={index} item={item} data={data} />
//           ))}
//         </FlexWrap>

//         <FlexWrap>
//           {/* Fix: Ensure WeeklyStatCard & CategoryChart render properly */}
//           {data?.TotalWeeklyCaloriBurnt ? (
//             <WeeklyStatCard data={data} />
//           ) : (
//             <p>Loading Weekly Data...</p>
//           )}

//           {data?.PieChartData ? (
//             <CategoryChart data={data} />
//           ) : (
//             <p>Loading Category Data...</p>
//           )}

//           <AddWorkout
//             workout={workout}
//             setWorkout={setWorkout}
//             AddWorkout={AddWorkout}
//             buttonLoading={buttonLoading}
//           />
//         </FlexWrap>
//       </Wrapper>
//     </Container>
//   );
// };







// import React, { useEffect, useState } from "react";
// import styled from "styled-components";
// import { counts } from "../utils/data";
// import CountsCard from "../components/cards/CountsCard";
// import WeeklyStatCard from "../components/cards/WeeklyStatCard";
// import CategoryChart from "../components/cards/CategoryChart";
// import AddWorkout from "../components/AddWorkout";
// import WorkoutCard from "../components/cards/Workoutcard";
// import { addWorkout, getDashboardDetails, getWorkouts } from "../api";

// const Container = styled.div`
//   flex: 1;
//   height: 100%;
//   display: flex;
//   justify-content: center;
//   padding: 22px 0px;
//   overflow-y: scroll;
// `;
// const Wrapper = styled.div`
//   flex: 1;
//   max-width: 1400px;
//   display: flex;
//   flex-direction: column;
//   gap: 22px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;
// const Title = styled.div`
//   padding: 0px 16px;
//   font-size: 22px;
//   color: ${({ theme }) => theme.text_primary};
//   font-weight: 500;
// `;
// const FlexWrap = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: space-between;
//   gap: 22px;
//   padding: 0px 16px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;
// const Section = styled.div`
//   display: flex;
//   flex-direction: column;
//   padding: 0px 16px;
//   gap: 22px;
//   padding: 0px 16px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;
// const CardWrapper = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: center;
//   gap: 20px;
//   margin-bottom: 100px;
//   @media (max-width: 600px) {
//     gap: 12px;
//   }
// `;

// const Dashboard = () => {
//   const [loading, setLoading] = useState(false);
//   const [data, setData] = useState();
//   const [buttonLoading, setButtonLoading] = useState(false);
//   const [todaysWorkouts, setTodaysWorkouts] = useState([]);
//   const [workout, setWorkout] = useState(`#Legs
// -Back Squat
// -5 setsX15 reps
// -30 kg
// -10 min`);

//   const dashboardData = async () => {
//     setLoading(true);
//     const token = localStorage.getItem("fittrack-app-token");
//     await getDashboardDetails(token).then((res) => {
//       setData(res.data);
//       console.log(res.data);
//       setLoading(false);
//     });
//   };
//   const getTodaysWorkout = async () => {
//     setLoading(true);
//     const token = localStorage.getItem("fittrack-app-token");
//     await getWorkouts(token, "").then((res) => {
//       setTodaysWorkouts(res?.data?.todaysWorkouts);
//       console.log(res.data);
//       setLoading(false);
//     });
//   };

//   const addNewWorkout = async () => {
//     setButtonLoading(true);
//     const token = localStorage.getItem("your_secret_key ");
//     await addWorkout(token, { workoutString: workout })
//       .then((res) => {
//         dashboardData();
//         getTodaysWorkout();
//         setButtonLoading(false);
//       })
//       .catch((err) => {
//         alert(err);
//       });
//   };

//   useEffect(() => {
//     dashboardData();
//     getTodaysWorkout();
//   }, []);
//   return (
//     <Container>
//       <Wrapper>
//         <Title>Dashboard</Title>
//         <FlexWrap>
//           {counts.map((item) => (
//             <CountsCard item={item} data={data} />
//           ))}
//         </FlexWrap>

//         <FlexWrap>
//           <WeeklyStatCard data={data} />
//           <CategoryChart data={data} />
//           <AddWorkout
//             workout={workout}
//             setWorkout={setWorkout}
//             addNewWorkout={addNewWorkout}
//             buttonLoading={buttonLoading}
//           />
//         </FlexWrap>

//         <Section>
//           <Title>Todays Workouts</Title>
//           <CardWrapper>
//             {todaysWorkouts.map((workout) => (
//               <WorkoutCard workout={workout} />
//             ))}
//           </CardWrapper>
//         </Section>
//       </Wrapper>
//     </Container>
//   );
// };

// export default Dashboard;










import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { counts } from "../utils/data";
import CountsCard from "../components/cards/CountsCard";
import WeeklyStatCard from "../components/cards/WeeklyStatCard";
import CategoryChart from "../components/cards/CategoryChart";
import AddWorkout from "../components/AddWorkout";
import WorkoutCard from "../components/cards/Workoutcard"; // Fixed import
import { addWorkout, getDashboardDetails, getWorkouts } from "../api";

const Container = styled.div`
  flex: 1;
  height: 100%;
  display: flex;
  justify-content: center;
  padding: 22px 0px;
  overflow-y: scroll;
`;

const Wrapper = styled.div`
  flex: 1;
  max-width: 1400px;
  display: flex;
  flex-direction: column;
  gap: 22px;
  @media (max-width: 600px) {
    gap: 12px;
  }
`;

const Title = styled.div`
  padding: 0px 16px;
  font-size: 22px;
  color: ${({ theme }) => theme.text_primary};
  font-weight: 500;
`;

const FlexWrap = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 22px;
  padding: 0px 16px;
  @media (max-width: 600px) {
    gap: 12px;
  }
`;

const Section = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0px 16px;
  gap: 22px;
  @media (max-width: 600px) {
    gap: 12px;
  }
`;

const CardWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  margin-bottom: 100px;
  @media (max-width: 600px) {
    gap: 12px;
  }
`;

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState();  //null
  const [buttonLoading, setButtonLoading] = useState(false);
  const [todaysWorkouts, setTodaysWorkouts] = useState([]);
  const [workout, setWorkout] = useState(`#Legs\n-Back Squat\n-5 setsX15 reps\n-30 kg\n-10 min`);

  // const dashboardData = async () => {
  //   try {
  //     setLoading(true);
  //     const token = localStorage.getItem("fittrack-app-token");
  //     if (!token) throw new Error("No token found");
      
  //     const res = await getDashboardDetails(token);
  //     setData(res?.data || {}); // Ensure data is never undefined
  //     console.log("Dashboard Data:", res.data);
  //   } catch (error) {
  //     console.error("Error fetching dashboard data:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const getTodaysWorkout = async () => {
  //   try {
  //     setLoading(true);
  //     const token = localStorage.getItem("fittrac-app-token");
  //     if (!token) throw new Error("No token found");

  //     const res = await getWorkouts(token, "fittrack-app-token");
  //     setTodaysWorkouts(res?.data?.todaysWorkouts || []);
  //     console.log("Today's Workouts:", res?.data);
  //   } catch (error) {
  //     console.error("Error fetching today's workouts:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const addNewWorkout = async () => {
  //   try {
  //     setButtonLoading(true);
  //     const token = localStorage.getItem("fittrack-app-token"); // Fixed token retrieval
  //     if (!token) throw new Error("No token found");

  //     await addWorkout(token, { workoutString: workout });

  //     // Refresh data after adding a workout
  //     await dashboardData();
  //     await getTodaysWorkout();
  //   } catch (error) {
  //     alert("Error adding workout: " + error.message);
  //   } finally {
  //     setButtonLoading(false);
  //   }
  // };




  const dashboardData = async () => {
    setLoading(true);
    const token = localStorage.getItem("fittrack-app-token");
    await getDashboardDetails(token).then((res) => {
      setData(res.data);
      console.log(res.data);
      setLoading(false);
    });
  };
  const getTodaysWorkout = async () => {
    setLoading(true);
    const token = localStorage.getItem("fittrack-app-token");
    await getWorkouts(token, "").then((res) => {
      setTodaysWorkouts(res?.data?.todaysWorkouts);
      console.log(res.data);
      setLoading(false);
    });
  };

  const addNewWorkout = async () => {
    setButtonLoading(true);
    const token = localStorage.getItem("fittrack-app-token");
    await addWorkout(token, { workoutString: workout })
      .then((res) => {
        dashboardData();
        getTodaysWorkout();
        setButtonLoading(false);
      })
      .catch((err) => {
        alert(err);
      });
  };

  useEffect(() => {
    dashboardData();
    getTodaysWorkout();
  }, []);

  return (
    <Container>
      <Wrapper>
        <Title>Dashboard</Title>

        {/* Stats Cards */}
        <FlexWrap>
          {/* {counts.map((item, index) => (
            <CountsCard key={index} item={item} data={data} />
          ))} */}
          {counts.map((item) => (
            <CountsCard item={item} data={data} />
          ))}
        </FlexWrap>

        {/* Weekly Stats & Charts */}
        <FlexWrap>
          <WeeklyStatCard data={data} />
          <CategoryChart data={data} />
          <AddWorkout
            workout={workout}
            setWorkout={setWorkout}
            addNewWorkout={addNewWorkout}
            buttonLoading={buttonLoading}
          />
        </FlexWrap>

        {/* Today's Workouts */}
        <Section>
          <Title>Today's Workouts</Title>
          <CardWrapper>
            {todaysWorkouts.length > 0 ? (
              todaysWorkouts.map((workout, index) => (
                <WorkoutCard key={index} workout={workout} />
              ))
            ) : (
              <p>No workouts for today.</p>
            )}
          </CardWrapper>
        </Section>
      </Wrapper>
    </Container>
  );
};

export default Dashboard;
